package com.example.countappv6;

public class MyHelper {
    public static Integer addMyValue(Integer originalValue) { return originalValue + 1;
    }
}
